# Employee Leave Management System --- Setup Guide

This guide explains how to run the supplied `EmployeeLeaveFresh.zip` on
another Windows or Ubuntu computer.

## 1. What this project uses

-   **Frontend:** Vue 3 + Vite
-   **Frontend-to-backend requests:** Native JavaScript `fetch()` (no
    Axios)
-   **Backend:** Java 17 + Spring Boot + Maven
-   **Database:** MongoDB
-   **API testing:** Postman (optional)
-   **IDE:** IntelliJ IDEA for the backend; any code editor can edit the
    frontend

Features include creating employees, viewing employees and leave
balances, applying for leave, and viewing leave records.

## 2. Extract the ZIP

Extract `EmployeeLeaveFresh.zip` to a folder you can easily find, such
as:

-   Windows: `C:\Users\<your-user>\Downloads\EmployeeLeaveFresh`
-   Ubuntu: `~/Downloads/EmployeeLeaveFresh`

**Important: the backend project is nested one level deeper than the
top-level folder in this ZIP.** Use these exact project locations after
extraction:

-   Frontend: `EmployeeLeaveFresh/frontend`
-   Backend: `EmployeeLeaveFresh/backend/EmployeeLeaveFresh`

The backend folder containing `pom.xml` is the one to open in IntelliJ.

## 3. Install required software

Install these tools on the new computer:

1.  **Java JDK 17** (or a compatible JDK supported by the project)
2.  **Node.js and npm**
3.  **MongoDB Community Server**
4.  **IntelliJ IDEA** (recommended for the backend)
5.  **MongoDB Compass** (optional, for viewing database records)
6.  **Postman** (optional, for testing APIs)

Maven wrapper scripts (`mvnw` and `mvnw.cmd`) are included, so a
separate Maven installation is normally not necessary.

### Verify installations

Open a terminal / PowerShell and run:

``` text
java -version
node -v
npm -v
```

On Windows, use PowerShell. On Ubuntu, use Terminal.

If any command is not recognised, install that tool and reopen the
terminal before continuing.

## 4. Start MongoDB

Make sure MongoDB Server is installed and running locally on port
`27017`.

### Windows

If MongoDB was installed as a Windows service, start it from Windows
Services or use an administrator PowerShell if your installation
requires it. The exact service name depends on how MongoDB was
installed.

### Ubuntu

If MongoDB was installed as a system service:

``` bash
sudo systemctl start mongod
sudo systemctl status mongod
```

These commands require an installation where the service is named
`mongod` and permission to manage the service. If MongoDB is already
running, you do not need to start it again.

The project uses this local connection string:

``` text
mongodb://localhost:27017/employee_leave_db
```

## 5. Configure the database

The backend configuration file is:

`backend/EmployeeLeaveFresh/src/main/resources/application.properties`

Its expected contents are:

``` properties
spring.application.name=employee-leave
server.port=8080
spring.data.mongodb.uri=mongodb://localhost:27017/employee_leave_db
```

This points the backend to the local MongoDB database named
`employee_leave_db`. Confirm that this database name is correct before
running the application. MongoDB will create the database and
collections when documents are first saved.

Expected collections:

-   `employees`
-   `leave_requests`

Do not expect existing data from the original computer to appear
automatically. MongoDB data is stored separately from the ZIP file. If
you need the original computer's records, export and import them
separately.

## 6. Start the backend

### Option A --- IntelliJ IDEA (recommended)

1.  Open IntelliJ IDEA.

2.  Choose **Open**.

3.  Select the backend project folder containing `pom.xml`:

    `EmployeeLeaveFresh/backend/EmployeeLeaveFresh`

4.  Allow IntelliJ/Maven to import the project and download
    dependencies.

5.  Find `EmployeeLeaveFreshApplication.java` in the package
    `com.example.employeeleavefresh`.

6.  Run its `main` method.

7.  Check the Run console for successful startup and a MongoDB
    connection.

The backend is configured to listen on:

``` text
http://localhost:8080
```

### Option B --- Run with the Maven wrapper

Open a terminal in the backend folder (the folder containing `pom.xml`).

**Windows PowerShell:**

``` powershell
.\mvnw.cmd spring-boot:run
```

**Ubuntu:**

``` bash
chmod +x mvnw
./mvnw spring-boot:run
```

The wrapper may need an internet connection on first run to download
Maven and dependencies. Keep this terminal open while using the
application.

## 7. Install and start the frontend

Open a **second** terminal. Do not stop the backend.

### Windows PowerShell

``` powershell
cd "$HOME\Downloads\EmployeeLeaveFresh\frontend"
npm install
npm run dev
```

If you extracted the ZIP to another folder, replace the path with your
actual frontend path.

### Ubuntu

``` bash
cd ~/Downloads/EmployeeLeaveFresh/frontend
npm install
npm run dev
```

Open the URL printed by Vite. It is usually:

``` text
http://localhost:5173
```

Keep the frontend terminal open. The frontend code sends API requests to
`http://localhost:8080/api`.

## 8. If the frontend uses another port

The backend controllers currently allow this frontend origin:

``` text
http://localhost:5173
```

If Vite reports that port `5173` is occupied and starts on `5174`
instead, the browser may show a CORS error. Either stop the other
process using the port so Vite can use `5173`, or update the
`@CrossOrigin` origin in both `EmployeeController.java` and
`LeaveController.java` to match the actual Vite origin. Restart Spring
Boot after changing it.

The allowed origin must match exactly, including the port.

## 9. Test the application

With MongoDB, Spring Boot, and Vue all running:

1.  Open the Vite URL in your browser.
2.  Add an employee using a name, unique employee code, department,
    email, and total leave allowance.
3.  Check that the employee appears in the Employees table.
4.  Copy the employee's complete MongoDB `id` from the table.
5.  Enter that ID in the Apply for Leave form, enter the number of days
    and purpose, and submit.
6.  Check the displayed leave records and available balance.

The employee ID for leave requests is the MongoDB document `id`, not the
human-readable employee code.

## 10. Test the backend with Postman (optional)

Base URL:

``` text
http://localhost:8080
```

### Create employee

-   Method: `POST`
-   URL: `http://localhost:8080/api/employees`
-   Body → raw → JSON:

``` json
{
  "name": "Arun Kumar",
  "employeeCode": "EMP101",
  "department": "CSE",
  "email": "arun@example.com",
  "totalLeaves": 12
}
```

A successful response should return the saved employee and its generated
MongoDB `id`.

### List employees

-   Method: `GET`
-   URL: `http://localhost:8080/api/employees`

### Apply for leave

Replace the example ID with the actual `id` returned by the employee
request.

-   Method: `POST`
-   URL: `http://localhost:8080/api/leaves`
-   Body → raw → JSON:

``` json
{
  "employeeId": "PASTE_REAL_EMPLOYEE_ID_HERE",
  "noOfDays": 2,
  "purpose": "Personal work"
}
```

### List leave records

-   Method: `GET`
-   URL: `http://localhost:8080/api/leaves`

## 11. Verify data in MongoDB Compass

1.  Open MongoDB Compass.

2.  Connect to:

    ``` text
    mongodb://localhost:27017
    ```

3.  Expand `employee_leave_db`.

4.  Open `employees` or `leave_requests`.

5.  Refresh the Documents view if needed.

You can also use `mongosh`:

``` javascript
use employee_leave_db
db.employees.find().pretty()
db.leave_requests.find().pretty()
db.employees.countDocuments()
db.leave_requests.countDocuments()
```

If Postman returns success but Compass appears empty, confirm you
selected the same MongoDB server and `employee_leave_db` database as the
connection string in `application.properties`.

## 12. Dependencies used by the project

### Frontend

The frontend dependencies are declared in `frontend/package.json`:

-   `vue`
-   `vite`
-   `@vitejs/plugin-vue`

`npm install` reads `package.json` and installs them. The project uses
native `fetch()` for HTTP calls and does **not** require Axios.

### Backend

The backend dependencies are declared in
`backend/EmployeeLeaveFresh/pom.xml`. They include Spring Boot's MongoDB
and web starters, Lombok, and test dependencies. Maven downloads them
when the project is imported or built.

Java 17 is configured in the Maven project. The Lombok dependency is
used by the backend code; if IntelliJ shows Lombok-related editor
errors, enable annotation processing or install/enable the Lombok plugin
in IntelliJ, then reload Maven.

## 13. Common problems

### `npm` or `node` is not recognised

Install Node.js, reopen the terminal, and check `node -v` and `npm -v`.

### Maven wrapper cannot run on Ubuntu

From the backend directory, run:

``` bash
chmod +x mvnw
./mvnw spring-boot:run
```

### MongoDB connection refused

Confirm MongoDB Server is installed and running on port `27017`. Compass
alone is only a GUI client; it is not the database server.

### `Failed to fetch` in the browser

-   Confirm Spring Boot is running on port `8080`.
-   Check the browser developer console for CORS errors.
-   Confirm Vite is running on port `5173`, or update both controllers'
    allowed origin to the port actually used.
-   Test the same endpoint in Postman.

### `400 Bad Request`

Check JSON field names. Employee creation expects `name`,
`employeeCode`, `department`, `email`, and `totalLeaves`. Leave
application expects `employeeId`, `noOfDays`, and `purpose`.

### `404 Not Found`

Check the endpoint path and HTTP method. The expected endpoints are
`/api/employees` and `/api/leaves`.

### Records appear in the wrong database

Check `spring.data.mongodb.uri` in `application.properties` and inspect
the same database name in Compass. This project should use
`employee_leave_db`; do not delete records from other databases while
troubleshooting.

## 14. Start-up order --- quick reference

1.  Start MongoDB Server.
2.  Run the Spring Boot backend from `backend/EmployeeLeaveFresh`.
3.  Run `npm install` once, then `npm run dev` from `frontend`.
4.  Open the Vite URL in the browser.
5.  Test employee creation and leave application.
6.  Confirm records in MongoDB Compass.
