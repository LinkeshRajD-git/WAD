
package com.example.employeeleavefresh.Model;

import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "employees")
public class Employee {
    @Id
    private String id;

    private String name;
    private String employeeCode;
    private String department;
    private String email;
    private int totalLeaves;
    @Setter
    private int leavesAvailable;

    public Employee() {}

    public Employee(String name, String employeeCode, String department,
                    String email, int totalLeaves) {
        this.name = name;
        this.employeeCode = employeeCode;
        this.department = department;
        this.email = email;
        this.totalLeaves = totalLeaves;
        this.leavesAvailable = totalLeaves;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmployeeCode() { return employeeCode; }
    public String getDepartment() { return department; }
    public String getEmail() { return email; }
    public int getTotalLeaves() { return totalLeaves; }
    public int getLeavesAvailable() { return leavesAvailable; }

}
