package com.example.employeeleavefresh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeLeaveFreshApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeLeaveFreshApplication.class, args);
    }

}
