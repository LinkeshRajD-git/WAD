package com.example.employeeleavefresh.Controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.example.employeeleavefresh.Model.Employee;
import com.example.employeeleavefresh.Repository.EmployeeRepository;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = "http://localhost:5173")
public class EmployeeController {
    private final EmployeeRepository repo;

    public EmployeeController(EmployeeRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Employee add(@RequestBody Employee employee) {
        if (employee.getName() == null || employee.getName().isBlank()
                || employee.getEmployeeCode() == null
                || employee.getEmployeeCode().isBlank()
                || employee.getDepartment() == null
                || employee.getEmail() == null
                || employee.getTotalLeaves() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Enter valid employee details");
        }

        if (repo.findByEmployeeCode(employee.getEmployeeCode()).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Employee code already exists");
        }

        Employee saved = new Employee(
                employee.getName(),
                employee.getEmployeeCode(),
                employee.getDepartment(),
                employee.getEmail(),
                employee.getTotalLeaves());

        return repo.save(saved);
    }

    @GetMapping
    public List<Employee> all() {
        return repo.findAll();
    }
}
