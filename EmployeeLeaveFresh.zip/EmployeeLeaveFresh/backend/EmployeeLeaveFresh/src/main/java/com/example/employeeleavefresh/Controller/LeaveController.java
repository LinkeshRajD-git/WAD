package com.example.employeeleavefresh.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.example.employeeleavefresh.Model.Employee;
import com.example.employeeleavefresh.Model.LeaveRequest;
import com.example.employeeleavefresh.Repository.EmployeeRepository;
import com.example.employeeleavefresh.Repository.LeaveRepository;

@RestController
@RequestMapping("/api/leaves")
@CrossOrigin(origins = "http://localhost:5173")
public class LeaveController {
    private final EmployeeRepository employees;
    private final LeaveRepository leaves;

    public LeaveController(EmployeeRepository employees,
                           LeaveRepository leaves) {
        this.employees = employees;
        this.leaves = leaves;
    }


    @PostMapping
    public Map<String, Object> apply(@RequestBody LeaveRequest request) {
        if (request.getEmployeeId() == null
                || request.getEmployeeId().isBlank()
                || request.getPurpose() == null
                || request.getPurpose().isBlank()
                || request.getNoOfDays() < 1) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Enter valid leave details");
        }

        Employee employee = employees.findById(request.getEmployeeId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee ID not found"));

        if (request.getNoOfDays() > employee.getLeavesAvailable()) {
            return Map.of(
                    "message", "Leave rejected: insufficient balance",
                    "status", "REJECTED",
                    "leavesAvailable", employee.getLeavesAvailable());
        }

        employee.setLeavesAvailable(
                employee.getLeavesAvailable() - request.getNoOfDays());
        employees.save(employee);

        LeaveRequest saved = leaves.save(new LeaveRequest(
                employee.getId(),
                employee.getName(),
                request.getNoOfDays(),
                request.getPurpose(),
                "APPROVED"));

        return Map.of(
                "message", "Leave approved successfully",
                "status", "APPROVED",
                "leave", saved,
                "leavesAvailable", employee.getLeavesAvailable());
    }

    @GetMapping
    public List<LeaveRequest> all() {
        return leaves.findAll();
    }
}

