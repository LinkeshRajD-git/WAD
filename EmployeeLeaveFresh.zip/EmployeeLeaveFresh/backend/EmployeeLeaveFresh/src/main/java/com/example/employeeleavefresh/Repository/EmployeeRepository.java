package com.example.employeeleavefresh.Repository;


import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.employeeleavefresh.Model.Employee;

public interface EmployeeRepository
        extends MongoRepository<Employee, String> {
    Optional<Employee> findByEmployeeCode(String employeeCode);
}

