package com.example.employeeleavefresh.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "leave_requests")
public class LeaveRequest {
    @Id
    private String id;

    private String employeeId;
    private String employeeName;
    private int noOfDays;
    private String purpose;
    private String status;

    public LeaveRequest() {}

    public LeaveRequest(String employeeId, String employeeName,
                        int noOfDays, String purpose, String status) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.noOfDays = noOfDays;
        this.purpose = purpose;
        this.status = status;
    }

    public String getId() { return id; }
    public String getEmployeeId() { return employeeId; }
    public String getEmployeeName() { return employeeName; }
    public int getNoOfDays() { return noOfDays; }
    public String getPurpose() { return purpose; }
    public String getStatus() { return status; }
}

