package com.example.employeeleavefresh.Repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.employeeleavefresh.Model.LeaveRequest;

public interface LeaveRepository
        extends MongoRepository<LeaveRequest, String> {
}

