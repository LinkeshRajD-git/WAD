
<script setup>
import { ref, onMounted } from 'vue'

const API = 'http://localhost:8080/api'
const employees = ref([])
const leaves = ref([])
const message = ref('')

const name = ref('')
const code = ref('')
const department = ref('')
const email = ref('')
const totalLeaves = ref(12)

const employeeId = ref('')
const noOfDays = ref(1)
const purpose = ref('')

async function api(url, options = {}) {
  const response = await fetch(API + url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    }
  })

  const data = await response.json().catch(() => null)

  if (!response.ok) {
    throw new Error(data?.message || data?.error || 'Request failed')
  }

  return data
}

async function loadData() {
  try {
    employees.value = await api('/employees')
    leaves.value = await api('/leaves')
  } catch (error) {
    message.value = error.message
  }
}

async function addEmployee() {
  try {
    await api('/employees', {
      method: 'POST',
      body: JSON.stringify({
        name: name.value,
        employeeCode: code.value,
        department: department.value,
        email: email.value,
        totalLeaves: Number(totalLeaves.value)
      })
    })

    message.value = 'Employee added successfully'
    name.value = ''
    code.value = ''
    department.value = ''
    email.value = ''
    totalLeaves.value = 12

    await loadData()
  } catch (error) {
    message.value = error.message
  }
}

async function applyLeave() {
  try {
    const result = await api('/leaves', {
      method: 'POST',
      body: JSON.stringify({
        employeeId: employeeId.value.trim(),
        noOfDays: Number(noOfDays.value),
        purpose: purpose.value
      })
    })

    message.value = result.message
    employeeId.value = ''
    noOfDays.value = 1
    purpose.value = ''

    await loadData()
  } catch (error) {
    message.value = error.message
  }
}

onMounted(loadData)
</script>

<template>
  <main>
    <h1>Employee Leave Management</h1>
    <p>{{ message }}</p>

    <hr>

    <h2>Add Employee</h2>

    <form @submit.prevent="addEmployee">
      <p>Name: <input v-model="name" required></p>
      <p>Employee Code: <input v-model="code" required></p>
      <p>Department: <input v-model="department" required></p>
      <p>Email: <input v-model="email" type="email" required></p>
      <p>Total Leaves:
        <input v-model.number="totalLeaves" type="number" min="0" required>
      </p>
      <button type="submit">Add Employee</button>
    </form>

    <hr>

    <h2>Employees</h2>
    <button @click="loadData">Refresh</button>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Code</th>
          <th>Department</th>
          <th>Leaves Available</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="e in employees" :key="e.id">
          <td>{{ e.id }}</td>
          <td>{{ e.name }}</td>
          <td>{{ e.employeeCode }}</td>
          <td>{{ e.department }}</td>
          <td>{{ e.leavesAvailable }}</td>
        </tr>
      </tbody>
    </table>

    <hr>

    <h2>Apply for Leave</h2>

    <form @submit.prevent="applyLeave">
      <p>Employee ID: <input v-model="employeeId" required></p>
      <p>Number of Days:
        <input v-model.number="noOfDays" type="number" min="1" required>
      </p>
      <p>Purpose: <input v-model="purpose" required></p>
      <button type="submit">Apply Leave</button>
    </form>

    <hr>

    <h2>Leave Records</h2>

    <table>
      <thead>
        <tr>
          <th>Leave ID</th>
          <th>Employee ID</th>
          <th>Employee Name</th>
          <th>Days</th>
          <th>Purpose</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="l in leaves" :key="l.id">
          <td>{{ l.id }}</td>
          <td>{{ l.employeeId }}</td>
          <td>{{ l.employeeName }}</td>
          <td>{{ l.noOfDays }}</td>
          <td>{{ l.purpose }}</td>
          <td>{{ l.status }}</td>
        </tr>
      </tbody>
    </table>
  </main>
</template>
